require('dotenv').config();
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const {
  Client, GatewayIntentBits, SlashCommandBuilder, PermissionFlagsBits, MessageFlags,
  EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder,
  TextInputBuilder, TextInputStyle, AttachmentBuilder, ChannelType,
} = require('discord.js');
const { createWorker } = require('tesseract.js');
const { baslikMatch, yorumPaneliMi, videoSayfasiMi, aboneKontrol, yorumuBul, adBul } = require('./helpers');

const {
  DISCORD_TOKEN,
  GUILD_ID,
  ROLE_ID,
  ROLE_NAME = 'Abonler',
  YT_CHANNEL_ID,
  YT_CHANNEL_NAME = 'ferhatrose35',
  MIN_YORUM_KARAKTER = '35',
  MIN_YORUM_KELIME = '5',
} = process.env;

const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages] });

// ---------- Kalıcı ayarlar (log kanalı + kullanılmış görsel hash'leri) ----------
const CONFIG_PATH = path.join(__dirname, 'config.json');
let config = { logChannelId: null, usedHashes: [] };
try { config = { ...config, ...JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8')) }; } catch {}
const saveConfig = () => fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2));
const usedHashes = new Set(config.usedHashes);

let worker;
const sessions = new Map(); // userId -> collector

// ---------- YouTube son video başlığı (RSS, API key gerekmez) ----------
let baslikCache = { t: 0, v: '' };
async function sonVideoBasligi() {
  if (Date.now() - baslikCache.t < 5 * 60_000 && baslikCache.v) return baslikCache.v;
  let channelId = YT_CHANNEL_ID;
  if (!channelId) {
    const handle = YT_CHANNEL_NAME.replace(/^@/, '');
    const pageRes = await fetch(`https://www.youtube.com/@${encodeURIComponent(handle)}`);
    if (!pageRes.ok) throw new Error('YouTube kanal sayfası alınamadı');
    const page = await pageRes.text();
    const idMatch = page.match(/"channelId"\s*:\s*"(UC[A-Za-z0-9_-]{22})"/) ||
      page.match(/channelId\\?"?\s*:\s*"(UC[A-Za-z0-9_-]{22})"/);
    if (!idMatch) throw new Error('YouTube kanal ID bulunamadı. YT_CHANNEL_ID değerini .env dosyasına ekle.');
    channelId = idMatch[1];
  }
  const res = await fetch(`https://www.youtube.com/feeds/videos.xml?channel_id=${channelId}`);
  if (!res.ok) throw new Error('YouTube RSS akışı alınamadı');
  const xml = await res.text();
  const m = xml.match(/<entry>[\s\S]*?<title>([\s\S]*?)<\/title>/);
  if (!m) throw new Error('Video başlığı alınamadı');
  const v = m[1].replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'");
  baslikCache = { t: Date.now(), v };
  return v;
}

// ---------- Yardımcılar ----------
const rolBul = (guild) => (ROLE_ID && guild.roles.cache.get(ROLE_ID)) || guild.roles.cache.find((r) => r.name === ROLE_NAME);
const yetkiliMi = (i) =>
  i.memberPermissions?.has(PermissionFlagsBits.ManageGuild) || i.memberPermissions?.has(PermissionFlagsBits.Administrator);
const resimler = (m) => [...m.attachments.values()].filter((a) => a.contentType?.startsWith('image/'));

async function ocr(buffer) {
  const { data } = await worker.recognize(buffer);
  return data.text || '';
}
async function indir(url) {
  const res = await fetch(url);
  return Buffer.from(await res.arrayBuffer());
}

function rolHataSebebi(err) {
  switch (err?.code) {
    case 50013: return 'Botun yetkisi yetersiz. Botun rolü, verilecek rolün **üstünde** olmalı ve botta **Rolleri Yönet** yetkisi açık olmalı.';
    case 10011: return 'Rol bulunamadı (ROLE_ID yanlış olabilir veya rol silinmiş).';
    case 10007:
    case 10013: return 'Kullanıcı sunucuda bulunamadı.';
    case 50001: return 'Botun bu sunucuya/kanala erişimi yok.';
    case 30005: return 'Sunucu rol sınırına ulaşıldı.';
    default: return `${err?.message || 'Bilinmeyen hata'}${err?.code ? ` (kod: ${err.code})` : ''}`;
  }
}

async function logla(guild, { user, ytAd, platform, satirlar, basarili, sebep, dosyalar }) {
  if (!config.logChannelId) return false;
  try {
    const ch = await guild.channels.fetch(config.logChannelId);
    const embed = new EmbedBuilder()
      .setColor(basarili ? 0x57f287 : 0xed4245)
      .setTitle(basarili ? '✅ Abone Doğrulandı' : '❌ Doğrulama Reddedildi')
      .addFields(
        { name: 'Kullanıcı', value: `<@${user.id}> (${user.tag})`, inline: true },
        { name: 'YouTube Adı', value: ytAd, inline: true },
        { name: 'Platform', value: platform || 'Bilinmiyor', inline: true },
        { name: 'Kontroller', value: satirlar || '-' }
      )
      .setTimestamp();
    if (sebep) embed.addFields({ name: 'Sebep', value: sebep.slice(0, 1000) });
    await ch.send({ embeds: [embed], files: dosyalar || [] });
    return true;
  } catch (e) {
    console.error('Log gönderilemedi:', e.message);
    return false;
  }
}

// ---------- Görsellerin analizi ----------
// Döner: { ok, platform, satirlar, sebepler, ... }
async function analiz(buffers, ytAd) {
  const metinler = [];
  for (const b of buffers) metinler.push(await ocr(b));

  let platform, aboneText, yorumText, tumText;
  if (buffers.length === 1) {
    platform = 'PC';
    const t = metinler[0];
    if (yorumPaneliMi(t) && !videoSayfasiMi(t)) {
      return { hata: 'Bu görsel mobil yorum paneline benziyor. **Mobilde 2 görseli aynı mesajda** göndermelisin (yorum paneli + kanal/video sayfası). PC\'de tam ekran tek görsel yeterli.' };
    }
    if (!videoSayfasiMi(t)) {
      return { hata: 'Görseli tanıyamadım. PC\'de **tam ekran** video sayfası olmalı (başlık, görüntüleme sayısı, abone butonu ve yorumun görünsün).' };
    }
    aboneText = yorumText = tumText = t;
  } else {
    platform = 'Mobil';
    const flags = metinler.map(yorumPaneliMi);
    if (flags.filter(Boolean).length !== 1) {
      return { hata: 'Mobilde 2 görsel gerekli: biri **yorum paneli** (\"En popüler / En yeni\" görünsün), diğeri **kanal/video sayfası** (\"Abone olundu\" görünsün).' };
    }
    yorumText = metinler[flags.indexOf(true)];
    aboneText = metinler[flags.indexOf(false)];
    tumText = metinler.join('\n');
  }

  const baslik = await sonVideoBasligi();
  const yorum = yorumuBul(yorumText);
  const sonuc = [
    ['Son video doğru', baslikMatch(tumText, baslik), 'Son videonun başlığı görüntülerde bulunamadı.'],
    ['Abone', aboneKontrol(aboneText, YT_CHANNEL_NAME), 'Abone olduğun görünmüyor ("Abone olundu" / zil ikonu ve kanal adı görünmeli).'],
    [
      'Yorum',
      yorum.karakter >= Number(MIN_YORUM_KARAKTER) && yorum.kelime >= Number(MIN_YORUM_KELIME),
      `Yeterince uzun yeni yorum bulunamadı (en az ${MIN_YORUM_KARAKTER} karakter / ${MIN_YORUM_KELIME} kelime ve "0 sn. önce" gibi yeni görünmeli).`,
    ],
    ['YouTube adı', adBul(yorumText, ytAd), 'Yazdığın YouTube adı yorumun yanında görünmüyor.'],
  ];
  return {
    platform,
    ok: sonuc.every(([, ok]) => ok),
    satirlar: sonuc.map(([ad, ok]) => `${ok ? '✅' : '❌'} ${ad}`).join('\n'),
    sebepler: sonuc.filter(([, ok]) => !ok).map(([, , s]) => `• ${s}`).join('\n'),
  };
}

// Tek bir gönderimi işle. true = rol verildi.
async function isle(m, ytAd) {
  const ch = m.channel;
  const user = m.author;
  const guild = m.guild;
  const imgs = resimler(m);
  const mention = `<@${user.id}>`;

  const rol = rolBul(guild);
  if (!rol) { await ch.send(`${mention} ⚠️ Rol bulunamadı, yetkililere haber ver.`); return true; }

  if (imgs.length > 2) {
    await ch.send(`${mention} ❌ Rol verilmedi\n**Sebep:** En fazla 2 görsel gönderebilirsin (Mobil: 2, PC: 1).`);
    return false;
  }

  const bekle = await ch.send(`${mention} 🔍 Görseller kontrol ediliyor, lütfen bekle...`);
  let buffers = [];
  try {
    buffers = await Promise.all(imgs.map((a) => indir(a.url)));
    const hashes = buffers.map((b) => crypto.createHash('sha256').update(b).digest('hex'));
    const dosyalar = () => imgs.map((a, i) => new AttachmentBuilder(buffers[i], { name: `ss${i + 1}-${a.name || 'img.png'}` }));

    if (hashes.some((h) => usedHashes.has(h))) {
      const sebep = 'Bu görsellerden biri daha önce kullanılmış.';
      await bekle.edit(`${mention} ❌ Rol verilmedi\n**Sebep:** ${sebep}`);
      await logla(guild, { user, ytAd, satirlar: '-', basarili: false, sebep, dosyalar: dosyalar() });
      return false;
    }

    const r = await analiz(buffers, ytAd);
    if (r.hata) {
      await bekle.edit(`${mention} ❌ Rol verilmedi\n**Sebep:** ${r.hata}`);
      return false;
    }

    if (!r.ok) {
      await bekle.edit(`${mention} ❌ Rol verilmedi\n${r.satirlar}\n\n**Sebep:**\n${r.sebepler}\n\nNet ve tam ekran SS'lerle tekrar gönder.`);
      await logla(guild, { user, ytAd, platform: r.platform, satirlar: r.satirlar, basarili: false, sebep: r.sebepler, dosyalar: dosyalar() });
      return false;
    }

    try {
      const member = await guild.members.fetch(user.id);
      await member.roles.add(rol);
    } catch (roleErr) {
      console.error('Rol verme hatası:', roleErr);
      const sebep = rolHataSebebi(roleErr);
      await bekle.edit(`${mention} ❌ Rol verilmedi\n${r.satirlar}\n\n**Sebep:** ${sebep}`);
      await logla(guild, { user, ytAd, platform: r.platform, satirlar: r.satirlar, basarili: false, sebep, dosyalar: dosyalar() });
      return false;
    }

    hashes.forEach((h) => usedHashes.add(h));
    config.usedHashes = [...usedHashes].slice(-5000);
    saveConfig();

    await bekle.edit(`${mention} 🎉 **Başarıyla rol verildi!** (${rol})\n${r.satirlar}`);
    const logladi = await logla(guild, { user, ytAd, platform: r.platform, satirlar: r.satirlar, basarili: true, dosyalar: dosyalar() });
    if (logladi) m.delete().catch(() => {}); // kanal temiz kalsın (log'da görseller var)
    return true;
  } catch (err) {
    console.error(err);
    await bekle.edit(`${mention} ⚠️ Rol verilmedi\n**Sebep:** Bir hata oluştu (${err.message}). Biraz sonra tekrar dene.`).catch(() => {});
    return false;
  }
}

// ---------- Oturum: modal sonrası görsel bekle ----------
async function oturumBaslat(i, ytAd) {
  sessions.get(i.user.id)?.stop('yeni');

  await i.reply({
    flags: MessageFlags.Ephemeral,
    content:
      `✅ YouTube adın: **${ytAd}**\n\n` +
      'Şimdi **bu kanala** görsellerini gönder (5 dakikan var):\n' +
      '📱 **Mobil:** Tek mesajda **2 görsel** → yorum paneli + kanal/video sayfası (abone olduğun görünsün)\n' +
      '💻 **PC:** Tek **tam ekran** görsel → video, abone butonu ve yorumun birlikte görünsün\n\n' +
      'Yorumun yeni olmalı ("0 sn. önce" görünsün). Bot mobil/PC\'yi kendisi anlar.',
  });

  const collector = i.channel.createMessageCollector({
    filter: (m) => m.author.id === i.user.id && resimler(m).length > 0,
    time: 5 * 60_000,
  });
  sessions.set(i.user.id, collector);

  let deneme = 0;
  let mesgul = false;
  collector.on('collect', async (m) => {
    if (mesgul) return;
    mesgul = true;
    try {
      const ok = await isle(m, ytAd);
      if (ok) collector.stop('ok');
      else if (++deneme >= 3) {
        collector.stop('hak');
        await m.channel.send(`<@${i.user.id}> ⛔ 3 deneme hakkın bitti. Paneldeki **Abone Doğrula** butonuna tekrar basıp yeniden dene.`);
      }
    } finally {
      mesgul = false;
    }
  });
  collector.on('end', (_, reason) => {
    if (sessions.get(i.user.id) === collector) sessions.delete(i.user.id);
    if (reason === 'time') i.followUp({ flags: MessageFlags.Ephemeral, content: '⌛ Süre doldu. Butona tekrar basarak yeniden başlayabilirsin.' }).catch(() => {});
  });
}

// ---------- Komutlar ----------
const komutlar = [
  new SlashCommandBuilder()
    .setName('kur')
    .setDescription('Abone doğrulama panelini bu kanala kurar')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  new SlashCommandBuilder()
    .setName('log')
    .setDescription('Doğrulama log kanalını ayarlar')
    .addChannelOption((o) =>
      o.setName('kanal').setDescription('Log kanalı').addChannelTypes(ChannelType.GuildText).setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
].map((c) => c.toJSON());

client.once('ready', async () => {
  worker = await createWorker(['tur', 'eng']);
  const guild = await client.guilds.fetch(GUILD_ID);
  await guild.commands.set(komutlar);
  console.log(`${client.user.tag} hazır.`);
});

client.on('interactionCreate', async (i) => {
  try {
    if (i.guildId !== GUILD_ID) return;

    if (i.isChatInputCommand()) {
      if (!yetkiliMi(i)) return i.reply({ flags: MessageFlags.Ephemeral, content: '⛔ Bu komutu sadece yetkililer kullanabilir.' });

      if (i.commandName === 'kur') {
        const embed = new EmbedBuilder()
          .setColor(0x5865f2)
          .setTitle('📺 YouTube Abone Doğrulama')
          .setDescription(
            'Abone rolünü almak için aşağıdaki **Abone Doğrula** butonuna bas.\n\n' +
              '**1.** YouTube adını yaz\n' +
              '**2.** Görsellerini gönder:\n' +
              '📱 Mobil: **2 görsel** (yorum paneli + kanal/video sayfası)\n' +
              '💻 PC: **1 tam ekran görsel**\n\n' +
              'Kanala abone olmalı ve son videoya yorum yazmış olmalısın.'
          );
        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('abone_dogrula').setLabel('Abone Doğrula').setEmoji('✅').setStyle(ButtonStyle.Success)
        );
        await i.channel.send({ embeds: [embed], components: [row] });
        return i.reply({ flags: MessageFlags.Ephemeral, content: '✅ Panel kuruldu.' });
      }

      if (i.commandName === 'log') {
        const kanal = i.options.getChannel('kanal');
        config.logChannelId = kanal.id;
        saveConfig();
        return i.reply({ flags: MessageFlags.Ephemeral, content: `✅ Log kanalı ${kanal} olarak ayarlandı.` });
      }
    }

    if (i.isButton() && i.customId === 'abone_dogrula') {
      const rol = rolBul(i.guild);
      if (rol && i.member.roles.cache.has(rol.id)) {
        return i.reply({ flags: MessageFlags.Ephemeral, content: '✅ Zaten doğrulanmışsın.' });
      }
      const modal = new ModalBuilder().setCustomId('abone_modal').setTitle('Abone Doğrulama').addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('yt_ad')
            .setLabel('YouTube Adın (@kullanıcıadı)')
            .setPlaceholder('Yorumda görünen adın, örn: @ahmet123')
            .setStyle(TextInputStyle.Short)
            .setMinLength(2)
            .setMaxLength(50)
            .setRequired(true)
        )
      );
      return i.showModal(modal);
    }

    if (i.isModalSubmit() && i.customId === 'abone_modal') {
      const ytAd = i.fields.getTextInputValue('yt_ad').trim();
      return oturumBaslat(i, ytAd);
    }
  } catch (e) {
    console.error(e);
    if (i.isRepliable() && !i.replied && !i.deferred) i.reply({ flags: MessageFlags.Ephemeral, content: '⚠️ Bir hata oluştu.' }).catch(() => {});
  }
});

client.login(DISCORD_TOKEN);
