// Türkçe karakterleri ve noktalamayı sadeleştir
function norm(s) {
  return String(s || '')
    .toLocaleLowerCase('tr')
    .replace(/ı/g, 'i').replace(/ğ/g, 'g').replace(/ü/g, 'u')
    .replace(/ş/g, 's').replace(/ö/g, 'o').replace(/ç/g, 'c')
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function lev(a, b) {
  const dp = Array.from({ length: a.length + 1 }, (_, i) => [i, ...Array(b.length).fill(0)]);
  for (let j = 0; j <= b.length; j++) dp[0][j] = j;
  for (let i = 1; i <= a.length; i++)
    for (let j = 1; j <= b.length; j++)
      dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
  return dp[a.length][b.length];
}
const benzerlik = (a, b) => 1 - lev(a, b) / Math.max(a.length, b.length, 1);

// Başlığın ilk 3 kelimesinden en az %60'ı SS'te var mı?
// (Başlık kesik göründüğü için kelimelerin sadece ilk 7 harfine bakılır)
function baslikMatch(ocrText, baslik) {
  const words = norm(baslik).split(' ').filter((w) => w.length > 2).slice(0, 3);
  if (!words.length) return false;
  const text = norm(ocrText);
  const hit = words.filter((w) => text.includes(w.slice(0, 7))).length;
  return hit >= Math.ceil(words.length * 0.6);
}

// Mobil yorum paneli mi? ("En popüler / En yeni" sekmeleri)
function yorumPaneliMi(ocrText) {
  const n = norm(ocrText);
  return (n.includes('en populer') && n.includes('en yeni')) || n.includes('yorum yazin');
}

// PC tam ekran video sayfası mı? (görüntüleme + yorum alanı)
function videoSayfasiMi(ocrText) {
  const n = norm(ocrText);
  // OCR "görüntüleme" kelimesini bozabilir; "Yorum ekleyin" de yeterli işaret
  return n.includes('yorum') && (n.includes('goruntuleme') || n.includes('yorum ekleyin') || /g\w?r\w{1,3}nt\w{2,5}me/.test(n));
}

// Abone kontrolü: "Abone olundu" yazısı veya (kanal adı var + "Abone ol" butonu yok → zil ikonu)
function aboneKontrol(ocrText, kanalAdi) {
  const n = norm(ocrText);
  const ad = norm(kanalAdi).replace(/\s/g, '');
  const adlar = [ad, ad.replace(/\d+$/, '')].filter((x) => x.length >= 4);
  const kanalVar = adlar.some((x) => n.replace(/\s/g, '').includes(x));
  if (!kanalVar) return false;
  if (/\babone olundu\b/.test(n)) return true;
  return !/\babone ol\b/.test(n);
}

// Yorum SS: "0 sn. önce", "2 dk. önce", "0 saniye önce" gibi yeni yorumun metnini bul
function yorumuBul(text) {
  // OCR "önce" kelimesini bazen "dnce/6nce/once" diye okur, o yüzden esnek
  const re = /((?:\d|[Oo]){1,2}\s*(?:sn|sani\w*|dk|dak\w*)\.?\s*\S?nce|[şs]imdi|az\s+\S?nce)/gi;
  let best = { kelime: 0, karakter: 0, metin: '' };
  let m;
  while ((m = re.exec(text)) !== null) {
    let rest = text.slice(m.index + m[0].length).replace(/^[\s•·|.]+/, '');
    rest = rest.split(/@|yorum eklendi|yorum yaz[ıi]n|yan[ıi]tla|\d+\s*yan[ıi]t/i)[0];
    const kelimeler = rest.split(/\s+/).filter((w) => /[a-zA-ZçğıöşüÇĞİÖŞÜ]{2,}/.test(w));
    if (kelimeler.length > best.kelime) {
      const metin = kelimeler.join(' ');
      best = { kelime: kelimeler.length, karakter: metin.length, metin };
    }
  }
  return best;
}

// Kullanıcının yazdığı YouTube adı SS'te geçiyor mu? (OCR hatalarına karşı bulanık eşleşme)
function adBul(ocrText, ad) {
  const hedef = norm(String(ad).replace(/^@/, '')).replace(/\s/g, '');
  if (hedef.length < 2) return false;
  const n = norm(ocrText);
  if (n.replace(/\s/g, '').includes(hedef)) return true;
  return n.split(' ').some((t) => t.length >= 3 && benzerlik(t, hedef) >= 0.75);
}

module.exports = { norm, baslikMatch, yorumPaneliMi, videoSayfasiMi, aboneKontrol, yorumuBul, adBul };
