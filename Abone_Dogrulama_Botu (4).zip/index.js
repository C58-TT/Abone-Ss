require('dotenv').config();
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const {
  Client, GatewayIntentBits, SlashCommandBuilder, PermissionFlagsBits, MessageFlags,
  EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle,
  AttachmentBuilder, ChannelType,
} = require('discord.js');
const { createWorker } = require('tesseract.js');
const { baslikMatch, yorumPaneliMi, videoSayfasiMi, aboneKontrol, yorumuBul, adBul } = require('./helpers');

const {
  DISCORD_TOKEN,
  GUILD_ID,
  VERIFY_CHANNEL_ID,
  ROLE_ID,
  ROLE_NAME = 'Abonler',
  YT_CHANNEL_ID,
  YT_CHANNEL_NAME = 'ferhatrose35',
  MIN_YORUM_KARAKTER = '35',
  MIN_YORUM_KELIME = '5',
} = process.env;

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

// ---------- Kalıcı ayarlar (log kanalı + kullanılmış görsel hash'leri) ----------
const CONFIG_PATH = path.join(__dirname, 'config.json');
let config = { logChannelId: null, usedHashes: [] };
try { config = { ...config, ...JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8')) }; } catch {}
const saveConfig = () => fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2));
const usedHashes = new Set(config.usedHashes);

let worker;

// ---------- YouTube son video başlığı (RSS, API key gerekmez) ----------
let baslikCache = { t: 0, v: '' };
async function sonVideoBasligi() {
  if (Date.now() - baslikCache.t < 5 * 60_000 && baslikCache.v) return baslikCache.v;
  let channelId = YT_CHANNEL_ID;
  if (!channelId) {
    const handle = YT_CHANNEL_NAME.replace(/^@/, '');
    const pageRes = await fetch(`https://www.youtube.com/@${encodeURIComponent(handle)}`);
    if (!pageRes.ok) throw new Error('YouTube kanal sayfası alınamadı');
    const page = await pageRes.text();
    const idMatch = page.match(/"channelId"\s*:\s*"(UC[A-Za-z0-9_-]{22})"/) ||
      page.match(/channelId\\?"?\s*:\s*"(UC[A-Za-z0-9_-]{22})"/);
    if (!idMatch) throw new Error('YouTube kanal ID bulunamadı. YT_CHANNEL_ID değerini .env dosyasına ekle.');
    channelId = idMatch[1];
  }
  const res = await fetch(`https://www.youtube.com/feeds/videos.xml?channel_id=${channelId}`);
  if (!res.ok) throw new Error('YouTube RSS akışı alınamadı');
  const xml = await res.text();
  const m = xml.match(/<entry>[\s\S]*?<title>([\s\S]*?)<\/title>/);
  if (!m) throw new Error('Video başlığı alınamadı');
  const v = m[1].replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'");
  baslikCache = { t: Date.now(), v };
  return v;
}

// ---------- Yardımcılar ----------
const rolBul = (guild) => (ROLE_ID && guild.roles.cache.get(ROLE_ID)) || guild.roles.cache.find((r) => r.name === ROLE_NAME);
const yetkiliMi = (i) =>
  i.memberPermissions?.has(PermissionFlagsBits.ManageGuild) || i.memberPermissions?.has(PermissionFlagsBits.Administrator);

async function ocr(buffer) {
  const { data } = await worker.recognize(buffer);
  return data.text || '';
}
async function indir(url) {
  const res = await fetch(url);
  return Buffer.from(await res.arrayBuffer());
}

function rolHataSebebi(err) {
  switch (err?.code) {
    case 50013: return 'Botun yetkisi yetersiz. Botun rolü, verilecek rolün **üstünde** olmalı ve botta **Rolleri Yönet** yetkisi açık olmalı.';
    case 10011: return 'Rol bulunamadı (ROLE_ID yanlış olabilir veya rol silinmiş).';
    case 10007:
    case 10013: return 'Kullanıcı sunucuda bulunamadı.';
    case 50001: return 'Botun bu sunucuya/kanala erişimi yok.';
    case 30005: return 'Sunucu rol sınırına ulaşıldı.';
    default: return `${err?.message || 'Bilinmeyen hata'}${err?.code ? ` (kod: ${err.code})` : ''}`;
  }
}

async function logla(guild, { user, ytAd, platform, satirlar, basarili, sebep, dosyalar }) {
  if (!config.logChannelId) return false;
  try {
    const ch = await guild.channels.fetch(config.logChannelId);
    const embed = new EmbedBuilder()
      .setColor(basarili ? 0x57f287 : 0xed4245)
      .setTitle(basarili ? '✅ Abone Doğrulandı' : '❌ Doğrulama Reddedildi')
      .addFields(
        { name: 'Kullanıcı', value: `<@${user.id}> (${user.tag})`, inline: true },
        { name: 'YouTube Adı', value: ytAd, inline: true },
        { name: 'Platform', value: platform || 'Bilinmiyor', inline: true },
        { name: 'Kontroller', value: satirlar || '-' }
      )
      .setTimestamp();
    if (sebep) embed.addFields({ name: 'Sebep', value: sebep.slice(0, 1000) });
    await ch.send({ embeds: [embed], files: dosyalar || [] });
    return true;
  } catch (e) {
    console.error('Log gönderilemedi:', e.message);
    return false;
  }
}

// ---------- Görsellerin analizi ----------
// Döner: { ok, platform, satirlar, sebepler, ... }
async function analiz(buffers, ytAd) {
  const metinler = [];
  for (const b of buffers) metinler.push(await ocr(b));

  let platform, aboneText, yorumText, tumText;
  if (buffers.length === 1) {
    platform = 'PC';
    const t = metinler[0];
    if (yorumPaneliMi(t) && !videoSayfasiMi(t)) {
      return { hata: 'Bu görsel mobil yorum paneline benziyor. **Mobilde 2 görseli aynı mesajda** göndermelisin (yorum paneli + kanal/video sayfası). PC\'de tam ekran tek görsel yeterli.' };
    }
    if (!videoSayfasiMi(t)) {
      return { hata: 'Görseli tanıyamadım. PC\'de **tam ekran** video sayfası olmalı (başlık, görüntüleme sayısı, abone butonu ve yorumun görünsün).' };
    }
    aboneText = yorumText = tumText = t;
  } else {
    platform = 'Mobil';
    const flags = metinler.map(yorumPaneliMi);
    if (flags.filter(Boolean).length !== 1) {
      return { hata: 'Mobilde 2 görsel gerekli: biri **yorum paneli** (\"En popüler / En yeni\" görünsün), diğeri **kanal/video sayfası** (\"Abone olundu\" görünsün).' };
    }
    yorumText = metinler[flags.indexOf(true)];
    aboneText = metinler[flags.indexOf(false)];
    tumText = metinler.join('\n');
  }

  const baslik = await sonVideoBasligi();
  const yorum = yorumuBul(yorumText);
  const sonuc = [
    ['Son video doğru', baslikMatch(tumText, baslik), 'Son videonun başlığı görüntülerde bulunamadı.'],
    ['Abone', aboneKontrol(aboneText, YT_CHANNEL_NAME), 'Abone olduğun görünmüyor ("Abone olundu" / zil ikonu ve kanal adı görünmeli).'],
    [
      'Yorum',
      yorum.karakter >= Number(MIN_YORUM_KARAKTER) && yorum.kelime >= Number(MIN_YORUM_KELIME),
      `Yeterince uzun yeni yorum bulunamadı (en az ${MIN_YORUM_KARAKTER} karakter / ${MIN_YORUM_KELIME} kelime ve "0 sn. önce" gibi yeni görünmeli).`,
    ],
    ['YouTube adı', adBul(yorumText, ytAd), 'Yazdığın YouTube adı yorumun yanında görünmüyor.'],
  ];
  return {
    platform,
    ok: sonuc.every(([, ok]) => ok),
    satirlar: sonuc.map(([ad, ok]) => `${ok ? '✅' : '❌'} ${ad}`).join('\n'),
    sebepler: sonuc.filter(([, ok]) => !ok).map(([, , s]) => `• ${s}`).join('\n'),
  };
}

// Modal gönderimini işle (görseller modaldan geliyor)
async function isle(i, ytAd, imgs) {
  const user = i.user;
  const guild = i.guild;
  const mention = `<@${user.id}>`;
  const edit = (content) => i.editReply({ content }).catch((e) => console.error('editReply:', e.message));

  const rol = rolBul(guild);
  if (!rol) return edit(`⚠️ Rol bulunamadı (ROLE_ID / "${ROLE_NAME}"). Yetkililere haber ver.`);

  if (imgs.length === 0 || imgs.length > 2) {
    return edit('❌ Rol verilmedi\n**Sebep:** Sadece görsel yükleyebilirsin (Mobil: 2, PC: 1).');
  }

  await edit('🔍 Görseller kontrol ediliyor, lütfen bekle...');
  try {
    const buffers = await Promise.all(imgs.map((a) => indir(a.url)));
    const hashes = buffers.map((b) => crypto.createHash('sha256').update(b).digest('hex'));
    const dosyalar = () => imgs.map((a, k) => new AttachmentBuilder(buffers[k], { name: `ss${k + 1}-${a.name || 'img.png'}` }));

    if (hashes.some((h) => usedHashes.has(h))) {
      const sebep = 'Bu görsellerden biri daha önce kullanılmış.';
      await edit(`❌ Rol verilmedi\n**Sebep:** ${sebep}`);
      await logla(guild, { user, ytAd, satirlar: '-', basarili: false, sebep, dosyalar: dosyalar() });
      return;
    }

    const r = await analiz(buffers, ytAd);
    if (r.hata) {
      await edit(`❌ Rol verilmedi\n**Sebep:** ${r.hata}`);
      return;
    }

    if (!r.ok) {
      await edit(`❌ Rol verilmedi\n${r.satirlar}\n\n**Sebep:**\n${r.sebepler}\n\nNet ve tam ekran SS'lerle butona tekrar basıp gönder.`);
      await logla(guild, { user, ytAd, platform: r.platform, satirlar: r.satirlar, basarili: false, sebep: r.sebepler, dosyalar: dosyalar() });
      return;
    }

    try {
      const member = await guild.members.fetch(user.id);
      await member.roles.add(rol);
    } catch (roleErr) {
      console.error('Rol verme hatası:', roleErr);
      const sebep = rolHataSebebi(roleErr);
      await edit(`❌ Rol verilmedi\n${r.satirlar}\n\n**Sebep:** ${sebep}`);
      await logla(guild, { user, ytAd, platform: r.platform, satirlar: r.satirlar, basarili: false, sebep, dosyalar: dosyalar() });
      return;
    }

    hashes.forEach((h) => usedHashes.add(h));
    config.usedHashes = [...usedHashes].slice(-5000);
    saveConfig();

    await edit(`🎉 **Başarıyla rol verildi!** (${rol.name})\n${r.satirlar}`);
    await logla(guild, { user, ytAd, platform: r.platform, satirlar: r.satirlar, basarili: true, dosyalar: dosyalar() });
  } catch (err) {
    console.error(err);
    await edit(`⚠️ Rol verilmedi\n**Sebep:** Bir hata oluştu (${err.message}). Biraz sonra tekrar dene.`);
  }
}

// ---------- Komutlar ----------
const komutlar = [
  new SlashCommandBuilder()
    .setName('kur')
    .setDescription('Abone doğrulama panelini bu kanala kurar')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  new SlashCommandBuilder()
    .setName('log')
    .setDescription('Doğrulama log kanalını ayarlar')
    .addChannelOption((o) =>
      o.setName('kanal').setDescription('Log kanalı').addChannelTypes(ChannelType.GuildText).setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
].map((c) => c.toJSON());

client.once('ready', async () => {
  console.log(`${client.user.tag} giriş yaptı.`);

  // Komutları ÖNCE kaydet (OCR dil verisi inerken beklemesin)
  try {
    const guild = await client.guilds.fetch(GUILD_ID);
    await guild.commands.set(komutlar);
    console.log(`✅ Slash komutları kaydedildi: ${komutlar.map((c) => '/' + c.name).join(', ')} (${guild.name})`);
  } catch (e) {
    console.error('❌ Slash komutları kaydedilemedi:', e.message, e.code ? `(kod: ${e.code})` : '');
    if (e.code === 50001 || e.code === 10004) {
      console.error('→ Bot bu sunucuda değil veya "applications.commands" yetkisiyle eklenmemiş. Botu aşağıdaki linkle tekrar ekle:');
      console.error(`https://discord.com/oauth2/authorize?client_id=${client.user.id}&scope=bot%20applications.commands&permissions=268504064`);
    }
  }

  try {
    console.log('OCR motoru hazırlanıyor (ilk açılışta dil verisi iner, internet gerekir)...');
    worker = await createWorker(['tur', 'eng']);
    console.log('✅ OCR hazır. Bot kullanıma hazır.');
  } catch (e) {
    console.error('❌ OCR başlatılamadı:', e.message);
  }
});

client.on('interactionCreate', async (i) => {
  try {
    if (i.guildId !== GUILD_ID) return;

    if (i.isChatInputCommand()) {
      if (!yetkiliMi(i)) return i.reply({ flags: MessageFlags.Ephemeral, content: '⛔ Bu komutu sadece yetkililer kullanabilir.' });

      if (i.commandName === 'kur') {
        const embed = new EmbedBuilder()
          .setColor(0x5865f2)
          .setTitle('📺 YouTube Abone Doğrulama')
          .setDescription(
            'Abone rolünü almak için aşağıdaki **Abone Doğrula** butonuna bas.\n\n' +
              '**1.** YouTube adını yaz\n' +
              '**2.** Açılan formda görsellerini yükle:\n' +
              '📱 Mobil: **2 görsel** (yorum paneli + kanal/video sayfası)\n' +
              '💻 PC: **1 tam ekran görsel**\n\n' +
              'Kanala abone olmalı ve son videoya yorum yazmış olmalısın.'
          );
        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('abone_dogrula').setLabel('Abone Doğrula').setEmoji('✅').setStyle(ButtonStyle.Success)
        );
        let hedef = i.channel;
        if (VERIFY_CHANNEL_ID) hedef = (await i.guild.channels.fetch(VERIFY_CHANNEL_ID).catch(() => null)) || i.channel;
        await hedef.send({ embeds: [embed], components: [row] });
        return i.reply({ flags: MessageFlags.Ephemeral, content: `✅ Panel ${hedef} kanalına kuruldu.` });
      }

      if (i.commandName === 'log') {
        const kanal = i.options.getChannel('kanal');
        config.logChannelId = kanal.id;
        saveConfig();
        return i.reply({ flags: MessageFlags.Ephemeral, content: `✅ Log kanalı ${kanal} olarak ayarlandı.` });
      }
    }

    if (i.isButton() && i.customId === 'abone_dogrula') {
      const rol = rolBul(i.guild);
      if (rol && i.member.roles.cache.has(rol.id)) {
        return i.reply({ flags: MessageFlags.Ephemeral, content: '✅ Zaten doğrulanmışsın.' });
      }
      const modal = {
        custom_id: 'abone_modal',
        title: 'Abone Doğrulama',
        components: [
          {
            type: 18, // Label
            label: 'YouTube Adın (@kullanıcıadı)',
            component: {
              type: 4, // Text input
              custom_id: 'yt_ad',
              style: 1,
              min_length: 2,
              max_length: 50,
              required: true,
              placeholder: 'Yorumda görünen adın, örn: @ahmet123',
            },
          },
          {
            type: 18,
            label: 'Ekran Görüntüleri (sadece görsel)',
            description: 'Mobil: 2 görsel (yorum paneli + kanal/video) • PC: 1 tam ekran',
            component: { type: 19, custom_id: 'ss_dosya', min_values: 1, max_values: 2, required: true }, // File upload
          },
        ],
      };
      return i.showModal(modal);
    }

    if (i.isModalSubmit() && i.customId === 'abone_modal') {
      const ytAd = i.fields.getTextInputValue('yt_ad').trim();
      let dosyalar;
      try {
        dosyalar = [...(i.fields.getUploadedFiles('ss_dosya', true).values())];
      } catch (e) {
        console.error('Dosya okunamadı:', e.message);
        return i.reply({ flags: MessageFlags.Ephemeral, content: '⚠️ Görseller okunamadı. Yetkililere haber ver (discord.js güncel olmalı: `npm install`).' });
      }
      await i.deferReply({ flags: MessageFlags.Ephemeral });
      const imgs = dosyalar.filter((a) => a.contentType?.startsWith('image/'));
      if (imgs.length !== dosyalar.length) {
        return i.editReply({ content: '❌ Rol verilmedi\n**Sebep:** Sadece görsel (png/jpg) yükleyebilirsin.' });
      }
      return isle(i, ytAd, imgs);
    }
  } catch (e) {
    console.error(e);
    if (i.isRepliable() && !i.replied && !i.deferred) i.reply({ flags: MessageFlags.Ephemeral, content: '⚠️ Bir hata oluştu.' }).catch(() => {});
  }
});

client.login(DISCORD_TOKEN);
