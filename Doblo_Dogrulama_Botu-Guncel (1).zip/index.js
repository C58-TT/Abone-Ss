require('dotenv').config();
const { Client, GatewayIntentBits } = require('discord.js');
const { createWorker } = require('tesseract.js');
const crypto = require('crypto');
const { baslikMatch, ssTuru, aboneKontrol, yorumuBul } = require('./helpers');

const {
  DISCORD_TOKEN,
  VERIFY_CHANNEL_ID,
  GUILD_ID,
  ROLE_ID,        // İsteğe bağlı. Boşsa "Abonler" isimli rol aranır
  ROLE_NAME = 'Abonler',
  YT_CHANNEL_ID,   // İsteğe bağlı: UC... kanal ID
  YT_CHANNEL_NAME = 'ferhatrose35', // Kanal adı/handle, @ olmadan
  MIN_YORUM_KARAKTER = '35',
  MIN_YORUM_KELIME = '5',
} = process.env;

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
  ],
});

const usedHashes = new Set(); // Aynı SS'in tekrar kullanılmasını engeller
let worker;

// En son videonun başlığını YouTube RSS'ten çek (API key gerekmez)
async function sonVideoBasligi() {
  let channelId = YT_CHANNEL_ID;

  // Kanal ID verilmediyse @handle sayfasından otomatik bul.
  if (!channelId) {
    const handle = YT_CHANNEL_NAME.replace(/^@/, '');
    const pageRes = await fetch(`https://www.youtube.com/@${encodeURIComponent(handle)}`);
    if (!pageRes.ok) throw new Error('YouTube kanal sayfası alınamadı');
    const page = await pageRes.text();
    const idMatch = page.match(/\"channelId\"\s*:\s*\"(UC[A-Za-z0-9_-]{22})\"/) ||
      page.match(/channelId\\?\"?\s*:\s*\"(UC[A-Za-z0-9_-]{22})\"/);
    if (!idMatch) throw new Error('YouTube kanal ID bulunamadı. YT_CHANNEL_ID değerini .env dosyasına ekle.');
    channelId = idMatch[1];
  }

  const res = await fetch(`https://www.youtube.com/feeds/videos.xml?channel_id=${channelId}`);
  if (!res.ok) throw new Error('YouTube RSS akışı alınamadı');
  const xml = await res.text();
  const m = xml.match(/<entry>[\s\S]*?<title>([\s\S]*?)<\/title>/);
  if (!m) throw new Error('Video başlığı alınamadı');
  return m[1].replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'");
}

function rolBul(guild) {
  return (ROLE_ID && guild.roles.cache.get(ROLE_ID)) || guild.roles.cache.find((r) => r.name === ROLE_NAME);
}

async function ocr(buffer) {
  const { data } = await worker.recognize(buffer);
  return data.text || '';
}

async function indir(url) {
  const res = await fetch(url);
  return Buffer.from(await res.arrayBuffer());
}

// Rol verme hatasını anlaşılır Türkçe sebebe çevir
function rolHataSebebi(err) {
  switch (err?.code) {
    case 50013:
      return 'Botun yetkisi yetersiz. Botun rolü, verilecek rolün **üstünde** olmalı ve botta **Rolleri Yönet** yetkisi açık olmalı.';
    case 10011:
      return 'Rol bulunamadı (ROLE_ID yanlış olabilir veya rol silinmiş).';
    case 10007:
    case 10013:
      return 'Kullanıcı sunucuda bulunamadı.';
    case 50001:
      return 'Botun bu sunucuya/kanala erişimi yok.';
    case 30005:
      return 'Sunucu rol sınırına ulaşıldı.';
    default:
      return `${err?.message || 'Bilinmeyen hata'}${err?.code ? ` (kod: ${err.code})` : ''}`;
  }
}

client.once('ready', async () => {
  worker = await createWorker(['tur', 'eng']);
  console.log(`${client.user.tag} hazır.`);
});

client.on('messageCreate', async (msg) => {
  if (msg.author.bot || msg.channel.id !== VERIFY_CHANNEL_ID || msg.guild?.id !== GUILD_ID) return;

  const rol = rolBul(msg.guild);
  if (!rol) return msg.reply(`⚠️ "${ROLE_NAME}" rolü bulunamadı. Yetkililere haber ver.`);
  if (msg.member?.roles.cache.has(rol.id)) {
    return msg.reply('✅ Zaten doğrulanmışsın.');
  }

  const imgs = [...msg.attachments.values()].filter((a) => a.contentType?.startsWith('image/'));
  if (imgs.length < 2) {
    return msg.reply(
      '**Tek mesajda 2 görsel** göndermelisin (sıra önemli değil):\n' +
        '📺 Son videoya girip çektiğin SS (abone olduğun, video bilgisi ve altındaki "Yorumlar" kutusu görünsün)\n' +
        '💬 Yorum panelinde, attığın uzun yorumun göründüğü SS'
    );
  }

  const bekle = await msg.reply('🔍 Görseller kontrol ediliyor, lütfen bekle...');

  try {
    const buffers = await Promise.all(imgs.slice(0, 2).map((a) => indir(a.url)));

    const hashes = buffers.map((b) => crypto.createHash('sha256').update(b).digest('hex'));
    if (hashes.some((h) => usedHashes.has(h))) {
      return bekle.edit('❌ Bu görsellerden biri daha önce kullanılmış.');
    }

    const metinler = [];
    for (const b of buffers) metinler.push(await ocr(b));

    const tur = metinler.map(ssTuru);
    const videoText = metinler[tur.indexOf('video')];
    const yorumText = metinler[tur.indexOf('yorum')];

    if (videoText === undefined || yorumText === undefined) {
      return bekle.edit(
        '❌ Görselleri tanıyamadım. Bir tanesi **video sayfası** (görüntüleme sayısı görünsün), diğeri **yorum paneli** ("En popüler / En yeni" görünsün) olmalı.'
      );
    }

    const baslik = await sonVideoBasligi();
    const yorum = yorumuBul(yorumText);

    const sonuc = [
      ['Son video doğru', baslikMatch(videoText, baslik)],
      ['Abone', aboneKontrol(videoText, YT_CHANNEL_NAME)],
      [
        'Uzun yorum',
        yorum.karakter >= Number(MIN_YORUM_KARAKTER) && yorum.kelime >= Number(MIN_YORUM_KELIME),
      ],
    ];

    const hepsi = sonuc.every(([, ok]) => ok);
    const satirlar = sonuc.map(([ad, ok]) => `${ok ? '✅' : '❌'} ${ad}`).join('\n');

    if (hepsi) {
      try {
        await msg.member.roles.add(rol);
      } catch (roleErr) {
        console.error('Rol verme hatası:', roleErr);
        const sebep = rolHataSebebi(roleErr);
        await bekle.edit(`${satirlar}\n\n❌ Rol verilemedi!\n**Sebep:** ${sebep}`);
        return;
      }

      hashes.forEach((h) => usedHashes.add(h));
      await bekle.edit(`${satirlar}\n\n🎉 Rolünüz başarıyla verildi!`);
    } else {
      await bekle.edit(
        `${satirlar}\n\nEksik olanları düzeltip 2 görseli tekrar gönder. SS'ler net ve tam ekran olmalı. Yorum SS'inde yorumun "0 sn. önce" gibi yeni görünmesi gerekir.`
      );
    }
  } catch (err) {
    console.error(err);
    await bekle.edit('⚠️ Bir hata oluştu, biraz sonra tekrar dene.');
  }
});

client.login(DISCORD_TOKEN);
