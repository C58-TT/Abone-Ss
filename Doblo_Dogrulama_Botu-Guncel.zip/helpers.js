// Türkçe karakterleri ve noktalamayı sadeleştir
function norm(s) {
  return s
    .toLocaleLowerCase('tr')
    .replace(/ı/g, 'i').replace(/ğ/g, 'g').replace(/ü/g, 'u')
    .replace(/ş/g, 's').replace(/ö/g, 'o').replace(/ç/g, 'c')
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

// Başlığın ilk 3 kelimesinden en az %60'ı SS'te var mı?
// (Videoda başlık kesik göründüğü için kelimelerin sadece ilk 7 harfine bakılır)
function baslikMatch(ocrText, baslik) {
  const words = norm(baslik).split(' ').filter((w) => w.length > 2).slice(0, 3);
  if (!words.length) return false;
  const text = norm(ocrText);
  const hit = words.filter((w) => text.includes(w.slice(0, 7))).length;
  return hit >= Math.ceil(words.length * 0.6);
}

// Hangi SS hangisi? (sıra önemli değil)
function ssTuru(ocrText) {
  const n = norm(ocrText);
  if (n.includes('en populer') && n.includes('en yeni')) return 'yorum';
  if (n.includes('goruntuleme')) return 'video';
  return null;
}

// Video sayfası SS: abone olunmuşsa "Abone ol" butonu yerine zil ikonu görünür.
// "yorumlar" kutusunun da görünmesi şart: buton satırı ekranda olmalı (kırpmayı zorlaştırır).
function aboneKontrol(ocrText, kanalAdi) {
  const n = norm(ocrText);
  return (
    n.includes(norm(kanalAdi)) &&
    n.includes('yorumlar') &&
    !/\babone ol\b/.test(n)
  );
}

// Yorum paneli SS: "0 sn. önce", "2 dk. önce", "şimdi" gibi yeni yorumların metnini bul
function yorumuBul(text) {
  const re = /(\d+\s*(?:sn|saniye|dk|dakika)\.?\s*[öo]nce|[şs]imdi|az\s+[öo]nce)/gi;
  let best = { kelime: 0, karakter: 0, metin: '' };
  let m;
  while ((m = re.exec(text)) !== null) {
    let rest = text.slice(m.index + m[0].length).replace(/^[\s•·|.]+/, '');
    rest = rest.split(/@|yorum eklendi|yorum yaz[ıi]n/i)[0];
    const kelimeler = rest.split(/\s+/).filter((w) => /[a-zA-ZçğıöşüÇĞİÖŞÜ]{2,}/.test(w));
    if (kelimeler.length > best.kelime) {
      const metin = kelimeler.join(' ');
      best = { kelime: kelimeler.length, karakter: metin.length, metin };
    }
  }
  return best;
}

module.exports = { norm, baslikMatch, ssTuru, aboneKontrol, yorumuBul };
